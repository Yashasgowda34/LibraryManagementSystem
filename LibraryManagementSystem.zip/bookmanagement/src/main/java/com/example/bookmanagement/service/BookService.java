package com.example.bookmanagement.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bookmanagement.entity.Book;
import com.example.bookmanagement.repository.BookRepository;

@Service
public class BookService {
	@Autowired
	private BookRepository bookRepository;
	//Create Book
	public Book saveBook(Book book) {
		return bookRepository.save(book);
		
	}
	//Get book by id
	public Book getBookById(Long id){
		return bookRepository.findById(id)
				.orElseThrow(()->new
						RuntimeException("Book not found with id:"+id));
		
	}
	//GetAllbook
	public List<Book>getAllBooks(){
		return bookRepository.findAll();
	}
	public Book updateBook(Long id,Book updatedBook) {
		Book existingBook=bookRepository.findById(id)
				.orElseThrow(()->new
						RuntimeException("Book not found with id:" +id));
		
		existingBook.setTitle(updatedBook.getTitle());
		existingBook.setAuthor(updatedBook.getAuthor());
		existingBook.setPrice(updatedBook.getPrice());
		
	    return bookRepository.save(existingBook);
	    }
	//DeleteBook
	public void deleteBook(Long id) {
		if(!bookRepository.existsById(id)) {
			throw new RuntimeException("Book not found with id:"+id);
		}
		bookRepository.deleteById(id);
	}
}
